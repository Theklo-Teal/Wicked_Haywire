@tool
extends Electronics

static func toybox_included() -> bool:
	return true

func _ready() -> void:
	#TODO add `sockets`.
	#TODO add `description`
	#TODO set `options`
	#TODO set `dwell` and `delay`
	
	
	#var input_socket = sockets.keys()[0]
	#watch_sockets.call_deferred(input_socket)
	pass

func _update_layout():
	match facing:
		pass

@warning_ignore_start("unused_parameter")
func _sim_update() -> Array[NetBase.Port]:
	return []

func _edge_triggered(socket: BitInput, rising:int, falling:int):
	pass

func _sim_update_sampling():
	pass

func _edge_triggered_sampling(socket: BitInput, rising:int, falling:int):
	pass

func _sim_update_respond():
	pass
@warning_ignore_restore("unused_parameter")
