@tool
extends Electronics

static func toybox_included() -> bool:
	return true

@export var flip_gate : bool : 
	set(val):
		flip_gate = val
		update_layout()
@export var flip_poles : bool : 
	set(val):
		flip_poles = val
		update_layout()

var state : bool = false
var gate : BitInput
var throw : BitRelay
var pole1 : BitRelay
var pole2 : BitRelay
var gate_cluster : Cluster
var throw_cluster : Cluster
var pole_cluster : Cluster

const front_panel = {
	FACE.EAST:0,
	FACE.SOUTH:1,
	FACE.WEST:2,
	FACE.NORTH:3
	}

const pressed_panel = {
	CORNER_BOTTOM_RIGHT:4,
	CORNER_BOTTOM_LEFT:5,
	CORNER_TOP_LEFT:6,
	CORNER_TOP_RIGHT:7
	} 

const release_panel = {
	CORNER_BOTTOM_RIGHT:8,
	CORNER_BOTTOM_LEFT:9,
	CORNER_TOP_LEFT:10,
	CORNER_TOP_RIGHT:11
	} 

func _ready() -> void:
	#TODO set `options`
	#TODO set `dwell` and `delay`
	
	gate = sockets.keys()[0]
	throw = sockets.keys()[1]
	pole1 = sockets.keys()[2]
	pole2 = sockets.keys()[3]
	gate_cluster = sockets[gate as GizmoSocket]
	throw_cluster = sockets[throw as GizmoSocket]
	pole_cluster = sockets[pole1 as GizmoSocket]

func entered_sim():
	_sim_update()

func _mirror(_axis_y:bool):
	flip_poles = not flip_poles

func altern_gate():
	flip_gate = not flip_gate

func _update_layout():
	pole_cluster.perpendicular = facing & FACE.VERTI != 0
	gate_cluster.perpendicular = facing & FACE.VERTI != 0
	pole_cluster.mirror_y = flip_poles
	gate_cluster.mirror_y = flip_gate
	var panel_1 = [release_panel, pressed_panel][int(flip_poles == state)]
	var panel_2 = [pressed_panel, release_panel][int(flip_poles == state)]
	match facing:
		FACE.EAST:
			throw_cluster.coord = Vector2(-1, 2)
			pole_cluster.coord = Vector2(0, 2)
			panels = {
				Vector4(-4, 0.5, -1.5, -1.5): front_panel[FACE.EAST],
				Vector4(0.5, 0.5, 2, 2.4): panel_1[CORNER_TOP_LEFT],
				Vector4(0.5, 2.7, 2, -1.5): panel_2[CORNER_BOTTOM_LEFT],
				}
		FACE.SOUTH:
			throw_cluster.coord = Vector2(2, -1)
			pole_cluster.coord = Vector2(2, 0)
			panels = {
				Vector4(0.5, -4, -1.5, -1.5): front_panel[FACE.SOUTH],
				Vector4(2.7, 0.5, -1.5, 2): panel_1[CORNER_TOP_RIGHT],
				Vector4(0.5, 0.5, 2.4, 2): panel_2[CORNER_TOP_LEFT],
				}
		FACE.WEST:
			throw_cluster.coord = Vector2(0, 2)
			pole_cluster.coord = Vector2(-1, 2)
			panels = {
				Vector4(0.5, 0.5, 3, -1.5): front_panel[FACE.WEST],
				Vector4(-3, 2.7, -1.5, -1.5): panel_1[CORNER_BOTTOM_RIGHT],
				Vector4(-3, 0.5, -1.5, 2.4): panel_2[CORNER_TOP_RIGHT],
				}
		FACE.NORTH:
			throw_cluster.coord = Vector2(2, 0)
			pole_cluster.coord = Vector2(2, -1)
			panels = {
				Vector4(0.5, 0.5, -1.5, 3):front_panel[FACE.NORTH],
				Vector4(0.5, 3, 2.4, -1.5):panel_1[CORNER_BOTTOM_LEFT],
				Vector4(2.7, 3, -1.5, -1.5):panel_2[CORNER_BOTTOM_RIGHT],
				}

func _sim_update() -> Array[NetBase.Port]:
	state = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and _mouse_hover and owner.mode == Flowchart.Mode.SIMULAT
	state = gate.read_bool() != state
	_update_layout()
	
	var bridges : Array[NetBase.Port]
	bridges.append(throw.port as NetBase.Port)
	bridges.append([pole1, pole2][int(state)].port as NetBase.Port)
	
	return bridges
