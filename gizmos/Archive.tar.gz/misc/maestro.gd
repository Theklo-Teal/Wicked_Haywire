@tool
extends Electronics

static func toybox_included() -> bool:
	return false

@export var phase : int = 0
@export var total : int = 60

var sock : BitOutput

func _ready() -> void:
	#TODO add `sockets`.
	#TODO add `description`
	#TODO set `options`
	#TODO set `dwell` and `delay`
	
	sock = sockets.keys()[0]

func _update_layout():
	match facing:
		pass

func _sim_update() -> Array[NetBase.Port]:
	var ticks = posmod(owner.jiffies + phase, total + 1)
	if ticks < %Low.value:
		$ProgressBar.value = remap(ticks, 0, %Low.value, 0, 100)
	else:
		$ProgressBar.value = remap(ticks, %Low.value, total, 100, 0)
	if ticks == total:
		sock.write_bool(0, true)
	elif ticks == %Low.value:
		sock.write_bool(0, false)
	return []

func _on_low_value_changed(value: float) -> void:
	total = %Low.value + %High.value
func _on_high_value_changed(value: float) -> void:
	total = %Low.value + %High.value
