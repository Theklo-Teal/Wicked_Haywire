@tool
extends Electronics

static func toybox_included() -> bool:
	return false

var bus : BitRelay
var taps : Array[BitRelay]

@export var wiring : Array[Array] = [[0,0], [1,1]]

func _ready() -> void:
	#TODO set `options`
	
	bus = sockets.keys()[0]
	taps.assign(sockets.keys().slice(1))

func _set_bitwidth():
	pass

func _update_layout():
	match facing:
		pass

func _sim_update():
	var bridges : Array[NetBase.Port]
	bridges.append(bus.port)
	
	for each in taps:
		bridges.append(each.port)
	
	#var i : int = -1
	#for span in wiring:
	#	i += 1
	return bridges

func _edge_triggered(_socket: BitInput, _rising:int, _falling:int):
	pass

func _sim_update_sampling():
	pass

func _edge_triggered_sampling(_socket: BitInput, _rising:int, _falling:int):
	pass

func _sim_update_respond():
	pass
